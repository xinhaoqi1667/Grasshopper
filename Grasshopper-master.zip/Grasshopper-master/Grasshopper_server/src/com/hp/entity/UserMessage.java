package com.hp.entity;

public class UserMessage {
private Integer id;

public UserMessage() {
	
	// TODO Auto-generated constructor stub
}

public UserMessage(Integer id) {
	super();
	this.id = id;
}

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

}
